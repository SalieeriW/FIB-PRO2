#include "LlistaIOEstudiant.hh"
using namespace std;


int main () {
    list <Estudiant> input;
    LlegirLlistaEstudiant(input);
    int n;
    cin >> n;
    list<Estudiant>::const_iterator it;
    int count = 0;
    for (it = input.begin(); it != input.end(); ++it) {
        if ((*it).consultar_DNI() == n) ++count;
    }
    cout << n << " " << count << endl;
}