#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::iterator it = l.end();
    int dni, mark;
    cin >> dni >> mark;
    while (dni != 0 and mark != 0) {
        Estudiant temp (dni);
        temp.afegir_nota(mark);
        l.insert(it,temp);
        cin >> dni >> mark;
    }
}
void EscriureLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::const_iterator it;
    for (it = l.begin(); it != l.end(); ++it) {
        (*it).escriure();
    }

}