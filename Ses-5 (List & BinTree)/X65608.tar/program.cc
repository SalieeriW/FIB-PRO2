#include "BinTreeIOEst.hh"

int findEstudent(const BinTree<Estudiant>& t, int dni, double& mark) {
    if (not t.empty()) {
        if (t.value().consultar_DNI() == dni) {
            if (t.value().te_nota()) mark = t.value().consultar_nota();
            else mark = -1;
            return 0;
        }

        double mark2;
        int l = findEstudent(t.left(), dni, mark);
        int d = findEstudent(t.right(), dni, mark2);

        if (l != -1 and d != -1) {
            if (l <= d) {
                return 1 + l;
            }
            else {
                mark = mark2;
                return 1 + d;
            }
        }

        if (l != -1) {
            return 1 + l;
        }
        else if (d != -1) {
            mark = mark2;
            return 1 + d;
        } else {
            return -1;
        }
    }
    return -1;
}


int main () {
    BinTree<Estudiant> est;
    read_bintree_est(est);

    int dni;
    while (cin >> dni) {
        double mark;
        int dist = findEstudent(est, dni, mark);
        if (dist != -1) {
            if (mark != -1) cout << dni << " " << dist << " " << mark << endl;
            else cout << dni << " " << dist << " " << -1 << endl;
        } else cout << dni << " " << -1 << endl;
    }
}