#include "BinTreeIOParInt.hh"

void read_bintree_parint(BinTree<ParInt>& a) {
    ParInt input;
    input.llegir();

    if (input.primer() != 0 and input.segon() != 0) {
        BinTree<ParInt> left;
        read_bintree_parint(left);
        BinTree<ParInt> right;
        read_bintree_parint(right);

        a = BinTree<ParInt> (input,left,right); 
    }
}

void write_bintree_parint(const BinTree<ParInt>& a) {
    if (not a.empty()) {
        write_bintree_parint(a.left());
        a.value().escriure();
        write_bintree_parint(a.right());
    }
}