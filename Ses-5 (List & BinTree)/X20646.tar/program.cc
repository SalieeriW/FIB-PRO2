#include "BinTreeIOParInt.hh"
using namespace std;

int search_tree(const BinTree<ParInt> &t, int num, int &second) {
    if (not t.empty()) {

        if (t.value().primer() == num) {
            second = t.value().segon();
            return 0;
        }
        int l = search_tree(t.left(), num, second);
         
        if (l != -1) 
            return 1 + l;

        int r = search_tree(t.right(), num, second);

        if (r != -1) 
            return 1 + r;
    }
    return -1;
}


int main () {
    BinTree <ParInt> t;
    read_bintree_parint(t);
    int num;
    while (cin >> num) {
        int second;
        int dist = search_tree(t, num, second);
        if (dist != -1) {
            cout << num << " " << second << " " << dist << endl;
        } else {
            cout << dist << endl;
        }
    }
}