#include <iostream>
#include "LlistaIOParInt.hh"

void LlegirLlistaParInt(list<ParInt>& l) {
    list <ParInt>::iterator it = l.end();
    ParInt input;
    while (input.llegir()) {
        l.insert(it, input);
    }
}

void EscriureLlistaParInt(const list<ParInt>& l) {
    list <ParInt>::const_iterator it;
    if (not l.empty()) {
        for (it = l.begin(); it != l.end(); ++it) {
            (*it).escriure();
        }
    }
}