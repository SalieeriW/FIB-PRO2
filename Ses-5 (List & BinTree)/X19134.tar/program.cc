#include "LlistaIOParInt.hh"
#include <list>
using namespace std;

int main () {
    list<ParInt> input;
    LlegirLlistaParInt(input);
    int n;
    cin >> n;

    int sum = 0;
    int count = 0;
    list<ParInt>::const_iterator it;
    for (it = input.begin(); it != input.end(); ++it) {
        if ((*it).primer() == n) {
            ++count;
            sum += (*it).segon();
        }
    }
    cout << n << " " << count << " " << sum << endl;
}