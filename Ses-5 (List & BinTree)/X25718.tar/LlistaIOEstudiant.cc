#include "LlistaIOEstudiant.hh"
#include <list>

void LlegirLlistaEstudiant(list<Estudiant>& l) {
    int dni;
    list<Estudiant>::iterator it = l.end();
    cin >> dni;
    while (dni != 0) {
        Estudiant temp (dni);
        int nota;
        cin >> nota;
        if (nota >= 0 and nota <= 10) temp.afegir_nota(nota);
        l.insert(it,temp);
        cin >> dni;
    }
    cin >> dni;
}
void EscriureLlistaEstudiant(const list<Estudiant>& l) {
    list<Estudiant>::const_iterator it;
    for (it = l.begin(); it != l.end(); ++it) {
        (*it).escriure();
    }
}